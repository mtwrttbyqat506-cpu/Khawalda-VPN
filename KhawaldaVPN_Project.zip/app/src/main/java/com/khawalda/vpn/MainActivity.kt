package com.khawalda.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.khawalda.vpn.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isConnected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    private fun setupUI() {
        binding.btnConnect.setOnClickListener {
            if (isConnected) {
                disconnectVpn()
            } else {
                startVpnAnimation()
            }
        }
    }

    private fun startVpnAnimation() {
        // إظهار مشهد الطائرات والضربة الجوية
        binding.animationContainer.visibility = View.VISIBLE
        binding.mainContent.visibility = View.GONE
        
        // تشغيل الرسوم المتحركة (Lottie أو Custom View)
        // هنا سنقوم بمحاكاة العملية
        binding.statusText.text = getString(R.string.status_connecting)
        
        binding.animationContainer.postDelayed({
            connectVpn()
        }, 5000) // 5 ثوانٍ للمحاكاة الحربية
    }

    private fun connectVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, 0)
        } else {
            onActivityResult(0, RESULT_OK, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            isConnected = true
            binding.statusText.text = getString(R.string.status_connected)
            binding.btnConnect.text = getString(R.string.disconnect)
            binding.animationContainer.visibility = View.GONE
            binding.mainContent.visibility = View.VISIBLE
            
            // إضافة تأثيرات بصرية للنجاح
            val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
            binding.statusIcon.startAnimation(pulse)
        }
    }

    private fun disconnectVpn() {
        isConnected = false
        binding.statusText.text = getString(R.string.status_disconnected)
        binding.btnConnect.text = getString(R.string.connect)
        binding.statusIcon.clearAnimation()
    }
}
